name=input()
name2=name.replace(":)","🙂").replace(":(","🙁")
print(name2)
