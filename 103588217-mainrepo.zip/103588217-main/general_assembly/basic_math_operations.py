def basic_op(operator, value1, value2):
    if operator == '+':
        return int(value1) + int(value2)

    elif operator == '-':
        return int(value1) - int(value2)

    elif operator == '*':
        return int(value1) * int(value2)

    elif operator == '/':
        return int(value1) / int(value2)
    #your code here