def solution(string):
    string = string[::-1]
    return string