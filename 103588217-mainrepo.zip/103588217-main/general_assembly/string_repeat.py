def repeat_str(repeat, string):
    return str(string)*int(repeat)