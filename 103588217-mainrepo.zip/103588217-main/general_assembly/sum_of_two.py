def sum_two_smallest_numbers(numbers):
    numbers.sort()
    return (int(numbers[0]) + int(numbers[1]))