def even_or_odd(number):
    if int(number) % 2 == 0:
        return 'Even'
    if int(number) % 2 == 1:
        return 'Odd'