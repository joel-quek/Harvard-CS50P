# x = int(input("What's x?"))
# y = int(input("What's y?"))


# print(x + y)

# print(int(input("What is x?"))+int(input("What is y?")))

x = float(input("What's x?"))
y = float(input("What's y?"))

# z=round(x+y,4) means round to 4 d.p.
z=round(x+y,4)
# print(z)
# f function is a format string
#print(f"{z:.2f}") means 2d.p.

print(f"{z:.2f}")

# stopped at 2hr mark