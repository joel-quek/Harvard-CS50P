students = {
    "Hermoine": "Gryffindor",
    "Harry": "Gryffindor",
    "Ron": "Gryffindor",
    "Draco": "Slytherin"
    }

# print (students ["Harry"])

for student in students:
    #print(students [student])
    #print(student)
    print(student, students[student], sep=", ")

