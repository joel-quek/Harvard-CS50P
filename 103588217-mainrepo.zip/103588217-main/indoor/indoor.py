name = input()
name2=name.lower()
print(name2)