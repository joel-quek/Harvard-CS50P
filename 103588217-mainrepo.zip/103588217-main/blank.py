#def main():
#    frac = 2/3
#    split = word_split(frac)
#    print(split)

#def word_split (x):

#    character = ()
x = 2/3
y = float(x)
print (y)
#y = [character for character in x]
#print(y)
#main()

#frac split works
frac = input("Fraction: ")
decimal = int(frac.split("/")[0]) / int(frac.split("/")[1])
print(decimal)
