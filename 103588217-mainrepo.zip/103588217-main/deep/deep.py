answer = input("What is the Answer to the Great Question of Life, the Universe, and Everything? ")
x  = "42"
y = "forty two"
z = "forty-two"

if answer == x or answer == y or answer == z:
    print("Yes")
else:
    print("No")