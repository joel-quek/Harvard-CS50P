#i = 0
#while i < 3:
#    print ("Meow")
#    i += 1
    # i += 1 is the same as i = i + 1
    # alternative
#for i in [0, 1, 2]:
for i in range(3):
    print ("Meow")

    # alternative
print ("Meow\n " * 3, end = "")
# \n is new line
# end = "" is to clear extra line