name=int(input("m: "))
E=(name*(300000000**2))
E2=round(E, 20)
print("E:", E2)