students = ["Hermoine", "Harry", "Ron", "Draco"]

houses = ["Gryffindor", "Gryffindor", "Gryffindor", "Slytherin"]

# print(students[1])
# alternative
#for _ in students:
#    print(_)

#alternative

for i in range(len(students)):
    # len is length
    # range creates a list [1,2,3]
    print(i + 1, students[i])
