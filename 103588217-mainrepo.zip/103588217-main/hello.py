#ask user for input
name = input("What's your name?")

#output the user's name. open and closed inverted commas for strings while + is to precede a variable/placeholder. + is for concatenationpyth
print("hello,", end="")
print (name)

print ("sup," + name, sep="")

print ("hello, \"friend\"")

print ('hello, "friend" ' )

#strip removes whitespace before input
# Python f strings embed expressions into a string literal. You can use f strings to embed variables, strings, or the results of functions into a string.
name=name.strip()
print (f"hello, {name}")

# capitalize only first word's first letter is caps
name = name.capitalize()
print (f"hello, {name} ")

# title allows first letter to be cap.
# You can even type ==>> name = input("What's your name?").strip().title()
name = name.strip().title()
print(f"hello, {name}")
