name = input("What is your name?")
def hello(to=name):
    print("Hello,", to)

hello(name)

#stopped at 2 H 13 Min