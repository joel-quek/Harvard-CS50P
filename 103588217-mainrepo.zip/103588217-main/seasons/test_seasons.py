import seasons
from seasons import main()

import pytest

def check_inputs:
    assert main(1989-10-18) == 

