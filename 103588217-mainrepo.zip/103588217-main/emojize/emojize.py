#pip install emoji keyed into command line
import emoji
x = input("Input: ")
print(emoji.emojize('Output: ' + x))




##import random
#from random import choice
##coin=random.choice(["heads","tails"])
#coin = choice(["heads","tails"])
#print(coin)

#import sys

#if len(sys.argv) < 2:
#    sys.exit("Too few arguments")

#for arg in sys.argv[1:]:
#    print("hello, my name is", arg)