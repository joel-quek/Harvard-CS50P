students = [
    {"name": "Hermoine", "house": "Gryffindor", "patronus": "Stag"},
    {"name": "Harry", "house": "Gryffindor", "patronus": "Otter"},
    {"name": "Ron", "house": "Gryffindor", "patronus": "Jack Russell Terrier"},
    {"name": "Draco", "house": "Slytherin", "patronus": None}
]

#DICTIONARIES

#for student in students:
#    print (student["name"], student["house"], student["patronus"], sep=", ")

shef = list(students)
shef2 = shef.index('name')
print(shef2)