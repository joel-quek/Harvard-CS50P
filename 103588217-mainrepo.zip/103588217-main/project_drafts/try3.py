x = range(6)
for i in x:
    print(i)