import tkinter
window = tkinter.Tk()

window.title('Hello Python')
window.geometry("300x200+10+20")
window.mainloop()
'''
from tkinter import *

root = Tk ()

w = Label(root, text="Hello, world!")
w.pack()

root.mainloop()
'''
# https://stackoverflow.com/questions/68547433/window-is-not-showing-up-at-all-in-vscode-tkinter
# https://stackoverflow.com/questions/34014148/how-to-install-tkinter-to-visual-studio-2015#:~:text=Tkinter%20should%20be%20installed%20by,Tcl%2FTk%20option%20is%20selected.