def song_decoder(song):
    x = song.replace("WUB", "")
    phrase = ""
    for word in x:
        phrase = phrase + " " + str(word)

    phrase = phrase.strip()
    return phrase

print(song_decoder("WUBWEWUBAREWUBWUBTHEWUBCHAMPIONSWUBMYWUBFRIENDWUB"))
print(song_decoder("AWUBBWUBC"))
print(song_decoder("AWUBWUBWUBBWUBWUBWUBC"))
print(song_decoder("WUBAWUBBWUBCWUB"))