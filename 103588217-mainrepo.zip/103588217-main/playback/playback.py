name = input()

name2=name.replace(" ", "...")
print(name2)